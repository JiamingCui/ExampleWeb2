# SnapNETS-Automatic-Segmentation-of-Network-Sequences-with-Node-Labels
Automatic Segmentation of Network Sequences with Node Labels (AAAI 2017)

Please follow the instruction in README.txt to prepare the inputs and run the code.

